export default [
  {
    code: 'en',
    name: 'English',
    direction: 'ltr'
  },
  {
    code: 'ar',
    name: 'عربى',
    direction: 'rtl'
  },
  {
    code: 'ar',
    name: 'عربى',
    direction: 'rtl'
  }
]
