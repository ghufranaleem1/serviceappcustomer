export default [
  {
    Image: 'https://images.unsplash.com/photo-1549068106-b024baf5062d?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60',
    Name: 'Zen Alint',
    Name_ar: 'زين ألينت',
    Review: 'Tejaswi has helped me out immensely to choose the best BOV vehicle for our facility. It has been a great experience with their service team who are prompt in attending and undertaken maintenance part from time to time.',
  },
  {
    Image: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60',
    Name: 'Aron Smith',
    Name_ar: 'آرون سميث',
    Review: 'The battery based auto has made my business double as people find it to be eco friendly and less noisy. Its a great comfort for people sitting and for carrying children ferrying to their schools.',
  },
  {
    Image: 'https://images.unsplash.com/photo-1542596768-5d1d21f1cf98?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
    Name: 'Stella',
    Name_ar: 'ستيلا',
    Review: 'It was rather strange experience in the beginning for riding without sound but not that I can understand its relevance and important Battrey has made my life that much more comfortable.',
  },
  {
    Image: 'https://images.unsplash.com/photo-1510486102594-9551be1c76d6?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60',
    Name: 'Amy Jahns',
    Name_ar: 'ايمي جانز',
    Review: 'It was rather strange experience in the beginning for riding without sound but not that I can understand its relevance and important Battrey has made my life that much more comfortable.',
  },
  {
    Image: 'https://images.unsplash.com/photo-1549780101-0c96c7eafbd9?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60',
    Name: 'Aahn Benz',
    Name_ar: 'آهن بنز',
    Review: 'It was rather strange experience in the beginning for riding without sound but not that I can understand its relevance and important Battrey has made my life that much more comfortable.',
  }
]
