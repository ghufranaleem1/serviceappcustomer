export default [
  {
    image: 'https://images.unsplash.com/photo-1549556889-cba541c33c0b?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1350&q=80',
    Text: '180 Wash',
    Text_ar: '180 غسل',
    descText: 'Checkout our package',
    descText_ar: 'تحقق من مجموعتنا'
  },
  {
    image: 'https://cdn.pixabay.com/photo/2015/12/08/00/28/car-1081742_960_720.jpg',
    Text: '360 Wash',
    Text_ar: '360 غسل',
    descText: 'Checkout our package',
    descText_ar: 'تحقق من مجموعتنا'
  },
  {
    image: 'https://cdn.pixabay.com/photo/2017/03/05/15/29/aston-2118857__340.jpg',
    Text: '120 Wash',
    Text_ar: '120 غسل',
    descText: 'Checkout our package',
    descText_ar: 'تحقق من مجموعتنا'
  },
  {
    image: 'https://images.unsplash.com/photo-1508519344352-489cf60571cf?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60',
    Text: '320 Wash',
    Text_ar: '320 غسل',
    descText: 'Checkout our package',
    descText_ar: 'تحقق من مجموعتنا'
  },
  {
    image: 'https://images.unsplash.com/photo-1563447243444-c77c2cbf2ac4?ixlib=rb-1.2.1&auto=format&fit=crop&w=680&q=80',
    Text: '150 Wash',
    Text_ar: '150 غسل',
    descText: 'Checkout our package',
    descText_ar: 'تحقق من مجموعتنا'
  }
]
