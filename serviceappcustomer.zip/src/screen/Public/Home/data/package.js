export default [
  {
    Text: 'Exterior Only',
    Text_ar: 'الخارج فقط',
    InfoText: '180 WASH',
    InfoText_ar: '180 غسيل',
    Service: 'Single Wash',
    Service_ar: 'غسيل واحد',
    price: '12',
    price_ar: '12'
  },
  {
    Text: 'Full Service',
    Text_ar: 'خدمة شاملة',
    InfoText: '360 WASH',
    InfoText_ar: '360 غسيل',
    Service: 'Single Wash',
    Service_ar: 'غسيل واحد',
    price: '24',
    price_ar: '24'
  },
  {
    Text: 'Full Service',
    Text_ar: 'خدمة شاملة',
    InfoText: 'ELITE WASH',
    InfoText_ar: 'غسيل النخبة',
    Service: 'Single Wash',
    Service_ar: 'غسيل واحد',
    price: '48',
    price_ar: '48'
  }
]
