export default [
  {
    time: '10:12 am',
    sessionActive: {
    }
  },
  {
    time: '09:12 pm',
    sessionActive: {
    }
  },
  {
    time: '10:12 am',
    sessionActive: {
      borderWidth: 1,
      borderColor: 'rgba(41, 41, 68, 1)'
    }
  },
  {
    time: '06:12 pm',
    sessionActive: {
    }
  },
  {
    time: '07:12 am',
    sessionActive: {
    }
  },
  {
    time: '03:12 pm',
    sessionActive: {
    }
  },
  {
    time: '05:12 am',
    sessionActive: {
    }
  },
  {
    time: '05:12 pm',
    sessionActive: {
    }
  },
  {
    time: '08:12 pm',
    sessionActive: {
    }
  },
  {
    time: '06:12 pm',
    sessionActive: {
    }
  },
  {
    time: '07:12 pm',
    sessionActive: {
    }
  },
  {
    time: '08:12 am',
    sessionActive: {
    }
  }
]
