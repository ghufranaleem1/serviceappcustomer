module.exports = {
    "assets": [
        "./node_modules/native-base/Fonts",
        "./assets/fonts"
    ]
};
